package application.entity;

public enum EventType {
	MOVIE,
	SPECTACLE,
	EXPOSITION,
	DANCE
	
}
